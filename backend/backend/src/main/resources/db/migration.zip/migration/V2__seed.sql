-- V3__seed.sql
-- ダミーデータ投入（ローカル開発用）
-- 既存データは破棄して入れ直す

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE CHAT_MESSAGE;
TRUNCATE TABLE NOTICE;
TRUNCATE TABLE TIME_PEOPLE;
TRUNCATE TABLE SHIFT_ASSIGN;
TRUNCATE TABLE SHIFT_DESIRED;
TRUNCATE TABLE SHIFT;
TRUNCATE TABLE SHIFT_RULE;
TRUNCATE TABLE STORE;
TRUNCATE TABLE EMPLOYEE;
TRUNCATE TABLE EMPLOYER;
TRUNCATE TABLE USERS;
TRUNCATE TABLE COMPANY;

SET FOREIGN_KEY_CHECKS = 1;

-- COMPANY（企業）
INSERT INTO COMPANY (company_id, company_name, address, phone)
VALUES (1, 'Test Company', 'Tokyo', '03-0000-0000');

-- USERS（ユーザー）: employee用(1) と employer用(2)
INSERT INTO USERS (user_id, mailaddress, password, name, phone, attribute)
VALUES
  (1, 'employee1@test.local', 'pass', 'Employee One', '090-0000-0001', 'employee'),
  (2, 'employer1@test.local', 'pass', 'Employer One', '090-0000-0002', 'employer');

-- EMPLOYER（雇用者）: user_id=2, company_id=1
INSERT INTO EMPLOYER (employer_id, user_id, company_id)
VALUES (1, 2, 1);

-- EMPLOYEE（被雇用者）: user_id=1
-- min_time/max_time は「分」など想定のINTとして適当に入れてる
INSERT INTO EMPLOYEE (employee_id, user_id, priority, min_time, max_time, newcomer)
VALUES (1, 1, 1, 240, 480, FALSE);

-- STORE（店舗）: company_id=1
INSERT INTO STORE (store_id, company_id, store_name, phone, address, time_open, time_close)
VALUES (1, 1, 'Test Store', '03-1111-1111', 'Shibuya', '09:00:00', '21:00:00');

-- SHIFT_RULE（シフトルール）: store_id=1
INSERT INTO SHIFT_RULE (shiftrule_id, store_id, time_people, priority, min_max_time, before_shift)
VALUES (1, 1, TRUE, TRUE, TRUE, FALSE);

-- SHIFT_DESIRED（希望シフト）: employee_id=1, store_id=1
-- ※あなたが貼ってくれたV1の定義は DATETIME なので日時で入れてる
INSERT INTO SHIFT_DESIRED (store_desired, employee_id, store_id, time_start, time_finish, situation)
VALUES (1, 1, 1, '2026-01-21 09:00:00', '2026-01-21 13:00:00', 'hold');

-- SHIFT（シフト）: created_by は EMPLOYER(employer_id)
INSERT INTO SHIFT (shift_id, store_id, shiftrule_id, time_start, time_finish, created_by)
VALUES (1, 1, 1, '2026-01-21 09:00:00', '2026-01-21 17:00:00', 1);

-- SHIFT_ASSIGN（割当）
INSERT INTO SHIFT_ASSIGN (shift_assign_id, shift_id, employee_id, shift_times, state)
VALUES (1, 1, 1, '2026-01-21 09:00:00', 'pending');

-- TIME_PEOPLE（時間帯人数）
INSERT INTO TIME_PEOPLE (time_people_id, store_id, pattern, min_people, max_people, newcomer)
VALUES (1, 1, 'weekday', 2, 5, 1);

-- NOTICE（通知）
INSERT INTO NOTICE (notice_id, user_id, kinds, notice)
VALUES (1, 1, 'info', 'seed notice');

-- CHAT_MESSAGE（チャット）
INSERT INTO CHAT_MESSAGE (chat_id, sender_id, receiver_id, content)
VALUES (1, 2, 1, 'Hello from employer to employee');
