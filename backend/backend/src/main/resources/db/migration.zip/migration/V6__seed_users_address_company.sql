INSERT INTO USERS (mailaddress, password, name, phone, attribute, address, company)
VALUES
('owner@test.com', 'password', 'テスト雇用者', '090-0000-0000', 'employer', '高知市', 'テスト店舗');

INSERT INTO STORE (store_name, address, phone)
VALUES
('テスト店舗', '高知市', '088-000-0000');

INSERT INTO USERS (mailaddress, password, name, phone, attribute, address)
VALUES
('emp1@test.com', 'password', 'テスト従業員A', '090-1111-1111', 'employee', '高知市'),
('emp2@test.com', 'password', 'テスト従業員B', '090-2222-2222', 'employee', '高知市'),
('emp3@test.com', 'password', 'テスト従業員C', '090-3333-3333', 'employee', '高知市');

INSERT INTO EMPLOYEE (user_id, store_id, priority, min_time, max_time, newcomer)
VALUES
(2, 1, 1, 3, 8, false),
(3, 1, 2, 4, 8, true),
(4, 1, 3, 2, 6, true);
