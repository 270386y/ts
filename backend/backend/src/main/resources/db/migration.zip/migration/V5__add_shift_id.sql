ALTER TABLE SHIFT_DESIRED
  ADD COLUMN shift_id BIGINT NULL;

-- 1つの希望が複数の確定シフトを持たないようにするなら
ALTER TABLE SHIFT_DESIRED
  ADD UNIQUE (shift_id);
