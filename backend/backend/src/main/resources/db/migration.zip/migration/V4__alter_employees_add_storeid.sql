/* 1) EMPLOYEE に store_id カラム追加（まずはNULL許可） */
ALTER TABLE EMPLOYEE
  ADD COLUMN store_id INT NULL;

/* 2) 既存データに store_id を入れる（例：従業員1は店舗1） */
UPDATE EMPLOYEE SET store_id = 1 WHERE employee_id = 1;

/* 必要に応じて他の従業員も更新
UPDATE EMPLOYEE SET store_id = 2 WHERE employee_id = 2;
*/

/* 3) 不整合チェック（store_id が存在しない店舗を指してないか） */
SELECT e.employee_id, e.store_id
FROM EMPLOYEE e
LEFT JOIN STORE s ON s.store_id = e.store_id
WHERE e.store_id IS NOT NULL AND s.store_id IS NULL;

/* 4) 外部キー制約を追加（削除時の挙動は好みで選ぶ） */
ALTER TABLE EMPLOYEE
  ADD CONSTRAINT fk_employee_store
  FOREIGN KEY (store_id) REFERENCES STORE(store_id)
  ON UPDATE CASCADE
  ON DELETE RESTRICT;

/* 5) 「必ず所属店舗が必要」なら NOT NULL にする（全員にstore_id入れた後で！） */
-- ALTER TABLE EMPLOYEE
--   MODIFY store_id INT NOT NULL;
